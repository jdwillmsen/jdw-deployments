structure load mob_skeleton_t1 ~ ~ ~ 0_degrees none true false
