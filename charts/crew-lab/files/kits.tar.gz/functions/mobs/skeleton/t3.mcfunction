structure load mob_skeleton_t3 ~ ~ ~ 0_degrees none true false
