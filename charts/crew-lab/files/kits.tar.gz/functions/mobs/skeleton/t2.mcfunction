structure load mob_skeleton_t2 ~ ~ ~ 0_degrees none true false
