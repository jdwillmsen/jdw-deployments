scoreboard players random roll kitroll 1 100
execute if score roll kitroll matches 1..50 run function mobs/skeleton/t4
execute if score roll kitroll matches 51..85 run function mobs/skeleton/t5
execute if score roll kitroll matches 86..100 run function mobs/skeleton/t6
