structure load mob_skeleton_t4 ~ ~ ~ 0_degrees none true false
