structure load mob_skeleton_t5 ~ ~ ~ 0_degrees none true false
