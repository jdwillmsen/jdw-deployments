structure load mob_skeleton_t6 ~ ~ ~ 0_degrees none true false
