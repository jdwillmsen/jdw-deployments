scoreboard players random roll kitroll 1 100
execute if score roll kitroll matches 1..30 run function mobs/stray/t1
execute if score roll kitroll matches 31..55 run function mobs/stray/t2
execute if score roll kitroll matches 56..75 run function mobs/stray/t3
execute if score roll kitroll matches 76..88 run function mobs/stray/t4
execute if score roll kitroll matches 89..96 run function mobs/stray/t5
execute if score roll kitroll matches 97..100 run function mobs/stray/t6
