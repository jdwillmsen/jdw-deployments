structure load mob_stray_t5 ~ ~ ~ 0_degrees none true false
