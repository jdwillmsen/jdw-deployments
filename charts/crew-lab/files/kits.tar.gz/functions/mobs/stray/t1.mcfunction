structure load mob_stray_t1 ~ ~ ~ 0_degrees none true false
