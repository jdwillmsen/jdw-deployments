structure load mob_stray_t4 ~ ~ ~ 0_degrees none true false
