structure load mob_stray_t6 ~ ~ ~ 0_degrees none true false
