structure load mob_stray_t3 ~ ~ ~ 0_degrees none true false
