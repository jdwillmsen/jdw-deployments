structure load mob_stray_t2 ~ ~ ~ 0_degrees none true false
