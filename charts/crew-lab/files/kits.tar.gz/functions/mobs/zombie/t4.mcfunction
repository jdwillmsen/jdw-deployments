structure load mob_zombie_t4 ~ ~ ~ 0_degrees none true false
