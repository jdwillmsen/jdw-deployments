structure load mob_zombie_t3 ~ ~ ~ 0_degrees none true false
