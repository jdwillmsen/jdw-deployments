structure load mob_zombie_t2 ~ ~ ~ 0_degrees none true false
