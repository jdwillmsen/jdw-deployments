structure load mob_zombie_t6 ~ ~ ~ 0_degrees none true false
