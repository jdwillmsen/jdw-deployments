structure load mob_zombie_t1 ~ ~ ~ 0_degrees none true false
