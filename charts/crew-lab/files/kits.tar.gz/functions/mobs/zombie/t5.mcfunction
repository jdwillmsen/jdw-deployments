structure load mob_zombie_t5 ~ ~ ~ 0_degrees none true false
