structure load mob_drowned_t3 ~ ~ ~ 0_degrees none true false
