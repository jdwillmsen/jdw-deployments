structure load mob_drowned_t2 ~ ~ ~ 0_degrees none true false
