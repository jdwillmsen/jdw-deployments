structure load mob_husk_t3 ~ ~ ~ 0_degrees none true false
