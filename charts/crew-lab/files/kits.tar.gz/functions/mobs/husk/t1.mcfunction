structure load mob_husk_t1 ~ ~ ~ 0_degrees none true false
