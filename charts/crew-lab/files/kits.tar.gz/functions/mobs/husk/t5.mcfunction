structure load mob_husk_t5 ~ ~ ~ 0_degrees none true false
