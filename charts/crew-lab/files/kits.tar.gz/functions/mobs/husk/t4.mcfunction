structure load mob_husk_t4 ~ ~ ~ 0_degrees none true false
