structure load mob_husk_t6 ~ ~ ~ 0_degrees none true false
