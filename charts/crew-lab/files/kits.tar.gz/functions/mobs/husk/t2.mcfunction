structure load mob_husk_t2 ~ ~ ~ 0_degrees none true false
