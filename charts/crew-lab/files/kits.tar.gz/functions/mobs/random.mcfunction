scoreboard players random pick kitroll 1 7
execute if score pick kitroll matches 1 run function mobs/zombie/roll
execute if score pick kitroll matches 2 run function mobs/husk/roll
execute if score pick kitroll matches 3 run function mobs/drowned/roll
execute if score pick kitroll matches 4 run function mobs/skeleton/roll
execute if score pick kitroll matches 5 run function mobs/stray/roll
execute if score pick kitroll matches 6 run function mobs/wither_skeleton/roll
execute if score pick kitroll matches 7 run function mobs/piglin/roll
