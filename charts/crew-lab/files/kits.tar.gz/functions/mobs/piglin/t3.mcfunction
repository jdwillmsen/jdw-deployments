structure load mob_piglin_t3 ~ ~ ~ 0_degrees none true false
