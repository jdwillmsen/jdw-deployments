structure load mob_piglin_t2 ~ ~ ~ 0_degrees none true false
