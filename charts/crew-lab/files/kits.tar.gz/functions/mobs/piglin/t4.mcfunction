structure load mob_piglin_t4 ~ ~ ~ 0_degrees none true false
