structure load mob_piglin_t1 ~ ~ ~ 0_degrees none true false
