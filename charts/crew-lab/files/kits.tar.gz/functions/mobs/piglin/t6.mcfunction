structure load mob_piglin_t6 ~ ~ ~ 0_degrees none true false
