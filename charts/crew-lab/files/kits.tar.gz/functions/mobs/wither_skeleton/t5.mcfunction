structure load mob_wither_skeleton_t5 ~ ~ ~ 0_degrees none true false
