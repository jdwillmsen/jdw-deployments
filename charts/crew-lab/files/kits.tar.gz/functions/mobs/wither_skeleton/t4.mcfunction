structure load mob_wither_skeleton_t4 ~ ~ ~ 0_degrees none true false
