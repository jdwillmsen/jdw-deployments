structure load mob_wither_skeleton_t6 ~ ~ ~ 0_degrees none true false
