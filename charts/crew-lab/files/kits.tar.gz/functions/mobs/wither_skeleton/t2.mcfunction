structure load mob_wither_skeleton_t2 ~ ~ ~ 0_degrees none true false
