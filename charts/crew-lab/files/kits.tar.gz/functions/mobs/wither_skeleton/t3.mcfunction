structure load mob_wither_skeleton_t3 ~ ~ ~ 0_degrees none true false
