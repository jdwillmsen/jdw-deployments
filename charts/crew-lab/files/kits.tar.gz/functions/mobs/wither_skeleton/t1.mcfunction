structure load mob_wither_skeleton_t1 ~ ~ ~ 0_degrees none true false
