scoreboard players random pick kitroll 1 12
execute if score pick kitroll matches 1 run function kits/vanguard/roll
execute if score pick kitroll matches 2 run function kits/duelist/roll
execute if score pick kitroll matches 3 run function kits/berserker/roll
execute if score pick kitroll matches 4 run function kits/ranger/roll
execute if score pick kitroll matches 5 run function kits/arbalist/roll
execute if score pick kitroll matches 6 run function kits/skybreaker/roll
execute if score pick kitroll matches 7 run function kits/lancer/roll
execute if score pick kitroll matches 8 run function kits/tidecaller/roll
execute if score pick kitroll matches 9 run function kits/scout/roll
execute if score pick kitroll matches 10 run function kits/miner/roll
execute if score pick kitroll matches 11 run function kits/homesteader/roll
execute if score pick kitroll matches 12 run function kits/netherraider/roll
