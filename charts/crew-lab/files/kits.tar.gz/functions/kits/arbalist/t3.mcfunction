structure load kit_arbalist_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Arbalist
tag @s add kitted
