structure load kit_arbalist_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Arbalist
tag @s add kitted
