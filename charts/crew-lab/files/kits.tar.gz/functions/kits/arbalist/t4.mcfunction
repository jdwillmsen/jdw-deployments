structure load kit_arbalist_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Arbalist
tag @s add kitted
