scoreboard players random roll kitroll 1 100
execute if score roll kitroll matches 1..50 run function kits/arbalist/t4
execute if score roll kitroll matches 51..85 run function kits/arbalist/t5
execute if score roll kitroll matches 86..100 run function kits/arbalist/t6
