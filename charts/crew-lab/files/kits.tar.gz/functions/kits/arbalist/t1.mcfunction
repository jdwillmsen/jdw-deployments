structure load kit_arbalist_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Arbalist
tag @s add kitted
