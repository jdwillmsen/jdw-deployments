structure load kit_arbalist_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Arbalist
tag @s add kitted
