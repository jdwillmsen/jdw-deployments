structure load kit_arbalist_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Arbalist
tag @s add kitted
