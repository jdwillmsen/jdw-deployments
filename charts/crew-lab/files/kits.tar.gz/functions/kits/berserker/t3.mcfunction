structure load kit_berserker_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Berserker
tag @s add kitted
