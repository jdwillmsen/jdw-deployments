structure load kit_berserker_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Berserker
tag @s add kitted
