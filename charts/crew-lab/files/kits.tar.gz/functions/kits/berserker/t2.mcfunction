structure load kit_berserker_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Berserker
tag @s add kitted
