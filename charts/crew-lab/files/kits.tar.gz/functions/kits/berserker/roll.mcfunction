scoreboard players random roll kitroll 1 100
execute if score roll kitroll matches 1..30 run function kits/berserker/t1
execute if score roll kitroll matches 31..55 run function kits/berserker/t2
execute if score roll kitroll matches 56..75 run function kits/berserker/t3
execute if score roll kitroll matches 76..88 run function kits/berserker/t4
execute if score roll kitroll matches 89..96 run function kits/berserker/t5
execute if score roll kitroll matches 97..100 run function kits/berserker/t6
