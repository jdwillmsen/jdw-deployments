structure load kit_berserker_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Berserker
tag @s add kitted
