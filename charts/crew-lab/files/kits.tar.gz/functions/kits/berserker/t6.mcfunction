structure load kit_berserker_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Berserker
tag @s add kitted
