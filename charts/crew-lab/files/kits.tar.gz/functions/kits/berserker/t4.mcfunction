structure load kit_berserker_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Berserker
tag @s add kitted
