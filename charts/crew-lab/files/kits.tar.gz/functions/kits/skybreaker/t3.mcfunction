structure load kit_skybreaker_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Skybreaker
tag @s add kitted
