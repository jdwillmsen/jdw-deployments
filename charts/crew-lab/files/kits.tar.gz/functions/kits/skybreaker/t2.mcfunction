structure load kit_skybreaker_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Skybreaker
tag @s add kitted
