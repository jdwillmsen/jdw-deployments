structure load kit_skybreaker_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Skybreaker
tag @s add kitted
