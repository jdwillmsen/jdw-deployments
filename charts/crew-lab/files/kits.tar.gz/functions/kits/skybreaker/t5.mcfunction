structure load kit_skybreaker_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Skybreaker
tag @s add kitted
