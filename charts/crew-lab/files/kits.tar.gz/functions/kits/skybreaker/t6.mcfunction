structure load kit_skybreaker_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Skybreaker
tag @s add kitted
