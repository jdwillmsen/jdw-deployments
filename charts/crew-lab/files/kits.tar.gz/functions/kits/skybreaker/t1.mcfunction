structure load kit_skybreaker_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Skybreaker
tag @s add kitted
