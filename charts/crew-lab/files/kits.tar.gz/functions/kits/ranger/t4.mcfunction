structure load kit_ranger_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Ranger
tag @s add kitted
