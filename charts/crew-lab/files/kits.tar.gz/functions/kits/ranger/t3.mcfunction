structure load kit_ranger_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Ranger
tag @s add kitted
