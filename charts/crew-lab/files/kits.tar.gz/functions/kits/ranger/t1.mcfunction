structure load kit_ranger_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Ranger
tag @s add kitted
