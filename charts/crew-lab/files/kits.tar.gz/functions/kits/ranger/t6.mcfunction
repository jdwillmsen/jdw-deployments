structure load kit_ranger_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Ranger
tag @s add kitted
