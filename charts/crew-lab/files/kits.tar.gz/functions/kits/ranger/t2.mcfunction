structure load kit_ranger_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Ranger
tag @s add kitted
