structure load kit_ranger_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Ranger
tag @s add kitted
