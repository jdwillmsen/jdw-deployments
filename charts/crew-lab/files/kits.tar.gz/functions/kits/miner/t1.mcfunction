structure load kit_miner_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Miner
tag @s add kitted
