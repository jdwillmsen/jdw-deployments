structure load kit_miner_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Miner
tag @s add kitted
