scoreboard players random roll kitroll 1 100
execute if score roll kitroll matches 1..30 run function kits/miner/t1
execute if score roll kitroll matches 31..55 run function kits/miner/t2
execute if score roll kitroll matches 56..75 run function kits/miner/t3
execute if score roll kitroll matches 76..88 run function kits/miner/t4
execute if score roll kitroll matches 89..96 run function kits/miner/t5
execute if score roll kitroll matches 97..100 run function kits/miner/t6
