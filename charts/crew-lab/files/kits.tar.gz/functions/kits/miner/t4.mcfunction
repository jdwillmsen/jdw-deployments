structure load kit_miner_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Miner
tag @s add kitted
