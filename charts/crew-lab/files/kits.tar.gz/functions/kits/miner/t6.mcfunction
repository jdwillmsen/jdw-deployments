structure load kit_miner_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Miner
tag @s add kitted
