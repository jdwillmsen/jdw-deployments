structure load kit_miner_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Miner
tag @s add kitted
