structure load kit_vanguard_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Vanguard
tag @s add kitted
