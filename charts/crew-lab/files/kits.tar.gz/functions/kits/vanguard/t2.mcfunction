structure load kit_vanguard_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Vanguard
tag @s add kitted
