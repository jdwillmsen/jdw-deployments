structure load kit_vanguard_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Vanguard
tag @s add kitted
