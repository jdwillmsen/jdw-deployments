structure load kit_vanguard_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Vanguard
tag @s add kitted
