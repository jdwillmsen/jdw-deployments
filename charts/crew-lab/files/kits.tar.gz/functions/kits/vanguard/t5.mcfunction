structure load kit_vanguard_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Vanguard
tag @s add kitted
