structure load kit_vanguard_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Vanguard
tag @s add kitted
