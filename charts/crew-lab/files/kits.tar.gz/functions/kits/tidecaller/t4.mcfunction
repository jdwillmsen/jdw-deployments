structure load kit_tidecaller_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Tidecaller
tag @s add kitted
