structure load kit_tidecaller_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Tidecaller
tag @s add kitted
