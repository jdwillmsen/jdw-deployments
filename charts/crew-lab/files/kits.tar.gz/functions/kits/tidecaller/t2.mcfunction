structure load kit_tidecaller_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Tidecaller
tag @s add kitted
