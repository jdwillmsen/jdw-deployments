structure load kit_tidecaller_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Tidecaller
tag @s add kitted
