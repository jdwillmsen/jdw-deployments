structure load kit_tidecaller_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Tidecaller
tag @s add kitted
