structure load kit_tidecaller_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Tidecaller
tag @s add kitted
