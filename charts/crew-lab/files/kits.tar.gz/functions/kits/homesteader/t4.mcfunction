structure load kit_homesteader_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Homesteader
tag @s add kitted
