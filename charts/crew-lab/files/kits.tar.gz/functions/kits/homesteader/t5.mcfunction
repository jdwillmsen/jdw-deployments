structure load kit_homesteader_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Homesteader
tag @s add kitted
