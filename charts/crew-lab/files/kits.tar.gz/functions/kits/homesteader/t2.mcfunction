structure load kit_homesteader_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Homesteader
tag @s add kitted
