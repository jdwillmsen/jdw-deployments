structure load kit_homesteader_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Homesteader
tag @s add kitted
