structure load kit_homesteader_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Homesteader
tag @s add kitted
