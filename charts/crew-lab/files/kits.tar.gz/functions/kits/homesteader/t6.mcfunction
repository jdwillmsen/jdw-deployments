structure load kit_homesteader_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Homesteader
tag @s add kitted
