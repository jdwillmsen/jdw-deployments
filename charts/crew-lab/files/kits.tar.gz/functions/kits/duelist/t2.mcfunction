structure load kit_duelist_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Duelist
tag @s add kitted
