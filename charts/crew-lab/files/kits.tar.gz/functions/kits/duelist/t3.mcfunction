structure load kit_duelist_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Duelist
tag @s add kitted
