structure load kit_duelist_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Duelist
tag @s add kitted
