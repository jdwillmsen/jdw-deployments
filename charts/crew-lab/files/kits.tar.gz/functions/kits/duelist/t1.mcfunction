structure load kit_duelist_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Duelist
tag @s add kitted
