structure load kit_duelist_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Duelist
tag @s add kitted
