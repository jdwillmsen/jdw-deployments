structure load kit_duelist_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Duelist
tag @s add kitted
