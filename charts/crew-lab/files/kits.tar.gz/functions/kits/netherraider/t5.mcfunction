structure load kit_netherraider_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Nether Raider
tag @s add kitted
