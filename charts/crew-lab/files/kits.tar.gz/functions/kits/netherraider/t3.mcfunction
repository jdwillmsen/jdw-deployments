structure load kit_netherraider_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Nether Raider
tag @s add kitted
