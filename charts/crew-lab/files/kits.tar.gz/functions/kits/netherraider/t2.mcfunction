structure load kit_netherraider_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Nether Raider
tag @s add kitted
