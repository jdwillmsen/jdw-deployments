structure load kit_netherraider_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Nether Raider
tag @s add kitted
