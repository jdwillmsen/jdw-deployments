structure load kit_netherraider_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Nether Raider
tag @s add kitted
