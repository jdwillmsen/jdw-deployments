structure load kit_netherraider_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Nether Raider
tag @s add kitted
