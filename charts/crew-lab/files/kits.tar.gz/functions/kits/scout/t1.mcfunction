structure load kit_scout_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Scout
tag @s add kitted
