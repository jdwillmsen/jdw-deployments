structure load kit_scout_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Scout
tag @s add kitted
