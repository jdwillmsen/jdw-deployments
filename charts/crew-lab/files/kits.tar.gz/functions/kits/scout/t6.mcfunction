structure load kit_scout_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Scout
tag @s add kitted
