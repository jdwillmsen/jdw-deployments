structure load kit_scout_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Scout
tag @s add kitted
