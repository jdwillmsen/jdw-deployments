structure load kit_scout_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Scout
tag @s add kitted
