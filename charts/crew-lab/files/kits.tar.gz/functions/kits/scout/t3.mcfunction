structure load kit_scout_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Scout
tag @s add kitted
