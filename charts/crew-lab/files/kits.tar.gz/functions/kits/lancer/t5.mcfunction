structure load kit_lancer_t5 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Legendary Lancer
tag @s add kitted
