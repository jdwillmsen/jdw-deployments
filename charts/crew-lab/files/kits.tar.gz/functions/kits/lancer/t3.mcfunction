structure load kit_lancer_t3 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Rare Lancer
tag @s add kitted
