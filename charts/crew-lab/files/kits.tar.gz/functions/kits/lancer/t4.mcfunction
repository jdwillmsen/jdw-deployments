structure load kit_lancer_t4 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Epic Lancer
tag @s add kitted
