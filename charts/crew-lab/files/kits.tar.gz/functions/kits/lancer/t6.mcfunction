structure load kit_lancer_t6 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Mythic Lancer
tag @s add kitted
