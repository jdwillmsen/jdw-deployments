structure load kit_lancer_t2 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Uncommon Lancer
tag @s add kitted
