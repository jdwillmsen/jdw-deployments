structure load kit_lancer_t1 ~ ~ ~ 0_degrees none true false
scriptevent kits:arrange Common Lancer
tag @s add kitted
